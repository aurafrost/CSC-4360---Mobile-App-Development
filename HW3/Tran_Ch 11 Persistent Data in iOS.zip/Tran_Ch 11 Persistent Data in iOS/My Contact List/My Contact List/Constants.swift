//
//  Constants.swift
//  My Contact List
//
//  Created by Iversen, Jakob H on 1/19/17.
//  Copyright © 2017 Leaning Mobile Apps. All rights reserved.
//

import Foundation
struct Constants {
      static let kSortField = "sortField"
      static let kSortDirectionAscending = "sortDirectionAscending"
}
