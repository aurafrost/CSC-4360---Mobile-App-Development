package com.example.jimmytran.helloworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText yourName;
    private TextView outputName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void helloReply(View v) {

        //Button helloButton = (Button) v;
        //((Button)v).setText("Hello");

        yourName = (EditText)findViewById(R.id.yourName);

        outputName = (TextView) findViewById(R.id.HelloReply);
        outputName.setText("Hello, " + yourName.getText() );
        outputName.setVisibility(View.VISIBLE);
    }

    public void byeReply(View v2) {

        yourName = (EditText)findViewById(R.id.yourName);

        outputName = (TextView) findViewById(R.id.ByeReply);
        outputName.setText("Goodbye, " + yourName.getText() );
        outputName.setVisibility(View.VISIBLE);
    }
}
